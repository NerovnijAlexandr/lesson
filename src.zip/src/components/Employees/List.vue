<template>
	
    <div id="emplye-list">
        <h1>Employees List</h1>
        <ul>
            <li v-for="employee of employees" 
                :key="employee.id"
            >{{ employee.employee_name }}</li>
    </ul>
    </div>

</template>


<script>
    // import axios from 'axios'

	export default {
        name: 'List',
        data() {
            return {
                employees: []
            }
        },
        methods: {
            getEmployees() {
                this.$http.get('http://dummy.restapiexample.com/api/v1/employees')
                .then(res => {
                    this.employees = res.data.data
                })
                .catch(e => {
                    console.log(e)
                })
            }
        },
        created() {
            this.getEmployees();
        }
	
	}


</script>



<style scoped>
	
</style>