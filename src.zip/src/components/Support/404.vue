<template>
	
	<div id="err404">
		<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative max-w-sm mx-auto" role="alert">
            <strong class="font-bold">Holy smokes!</strong>
            <span class="block sm:inline">404.</span>
        </div>
	</div>	
			

</template>


<script>
	

	export default {
		name: "404",
		
	} 


</script>



<style scoped>
	
</style>